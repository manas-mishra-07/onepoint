<?php
require 'Db.php';
class Query extends Db{
    public function select($table){
       $sql="select * from $table";
       $execute=mysqli_query($this->conn,$sql);
       $result=[];
       while($record=mysqli_fetch_assoc($execute)){
               array_push($result,$record);
       }
       return $result;
    }
 public function get_where($table,array $array){
     $where='where ';
     foreach($array as $k=>$v){
         $where.=$k.'="'.$v.'"';
     }
     $sql='select * from '.$table.' '.$where;
     $exe=mysqli_query($this->conn,$sql);
     $result=[];
     while($record=mysqli_fetch_assoc($exe)){
         array_push($result,$record);
     }
     return $result;
 }
}
?>