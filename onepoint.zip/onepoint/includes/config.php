<?php
define('BASE_URL','http://localhost/onepoint/');
define('server','localhost');
define('user','root');
define('password','');
define('database','onepoint');
?>