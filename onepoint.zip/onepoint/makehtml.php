<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require 'autoload.php';
$db=new Query();
$html=new CreateHtml();
if(isset($_POST['action'])){
$records=$html->makeHtml($db,'citydata');
$html->create_json('citydata','city.json',$db->select('citydata'));
}
?>